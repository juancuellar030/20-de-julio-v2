// Simple, pleasant, kid-friendly UI sounds synthesized with the Web Audio API.
// No external MP3s to source/host — generated on the fly, always available offline.

const SFX = (() => {
  let ctx = null;
  function getCtx() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    return ctx;
  }

  function tone(freq, start, duration, type = 'sine', gainPeak = 0.18) {
    const ac = getCtx();
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, ac.currentTime + start);
    gain.gain.linearRampToValueAtTime(gainPeak, ac.currentTime + start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + start + duration);
    osc.connect(gain).connect(ac.destination);
    osc.start(ac.currentTime + start);
    osc.stop(ac.currentTime + start + duration + 0.05);
  }

  return {
    playCorrect() {
      // cheerful ascending major triad
      tone(523.25, 0, 0.22, 'triangle');    // C5
      tone(659.25, 0.09, 0.22, 'triangle'); // E5
      tone(783.99, 0.18, 0.3, 'triangle');  // G5
    },
    playIncorrect() {
      // gentle two-note descending — not harsh
      tone(392.0, 0, 0.2, 'sine', 0.14);   // G4
      tone(311.13, 0.12, 0.3, 'sine', 0.14); // Eb4
    },
    playClick() {
      tone(700, 0, 0.08, 'square', 0.06);
    }
  };
})();
