// Quiz data — content copied EXACTLY from the source markdown files.
// Do not alter question text, options, or correct answers.

const QUIZ_1_3 = {
  gradeLabel: "1° a 3°",
  historyVideoId: "8DaNSJifI60",
  questions: [
    {
      number: 1,
      text: "¿Qué país gobernaba a Colombia antes de la Independencia?",
      type: "text",
      image: null,
      options: [
        { letter: "A", text: "Brasil." },
        { letter: "B", text: "España.", correct: true },
        { letter: "C", text: "México." },
        { letter: "D", text: "Argentina." }
      ]
    },
    {
      number: 2,
      text: "¿Qué objeto aparece en la historia del 20 de julio y ayudó a iniciar la discusión?",
      type: "image-options",
      image: null,
      options: [
        { letter: "A", text: "Una bandera.", image: "https://spanishglory.com/wp-content/uploads/2024/09/spain-379535_1280-1024x768.jpg" },
        { letter: "B", text: "Un sombrero.", image: "https://mundodelganadero.com/cdn/shop/products/image_cfb3f664-edec-4994-8262-96bd24c282e4_1200x1200.heic?v=1650406282" },
        { letter: "C", text: "Un florero.", image: "https://raw.githubusercontent.com/JhamG9/api-viaja/refs/heads/main/uploads/museo-de-la-independencia-casa-del-florero/florero-de-llorente-museo.webp", correct: true },
        { letter: "D", text: "Una espada.", image: "https://i00.eu/img/602/1024x1024/43nal3sz/30452.jpg" }
      ]
    },
    {
      number: 3,
      text: "¿Cómo se llamaban las personas nacidas en América que querían participar en el gobierno?",
      type: "text",
      image: "https://www.superprof.co/blog/wp-content/uploads/2025/02/crioillos-dia-independencia.jpg",
      options: [
        { letter: "A", text: "Indígenas." },
        { letter: "B", text: "Criollos.", correct: true },
        { letter: "C", text: "Campesinos." },
        { letter: "D", text: "Soldados." }
      ]
    },
    {
      number: 4,
      text: "¿Qué celebramos los colombianos cada 20 de julio?",
      type: "text",
      image: "https://media.cnn.com/api/v1/images/stellar/prod/cnne-1423852-colombia-independence-anniversary.jpg?c=16x9&q=h_833,w_1480,c_fill",
      options: [
        { letter: "A", text: "La Independencia de Cartagena." },
        { letter: "B", text: "El inicio de la Independencia.", correct: true },
        { letter: "C", text: "El Día de los Niños." },
        { letter: "D", text: "La Batalla de Boyacá." }
      ]
    },
    {
      number: 5,
      text: "¿Qué querían los colombianos al comenzar el proceso de independencia?",
      type: "text",
      image: null,
      options: [
        { letter: "A", text: "Gobernar su propio país.", correct: true },
        { letter: "B", text: "Viajar a otros continentes." },
        { letter: "C", text: "Construir más ciudades." },
        { letter: "D", text: "Cambiar el nombre del país." }
      ]
    }
  ]
};

const QUIZ_4_5 = {
  gradeLabel: "4° a 5°",
  historyVideoId: "qjIiUdCGcrI",
  questions: [
    {
      number: 1,
      text: "Según el video, ¿cuál fue la verdadera intención de los criollos al pedir prestado el florero de Llorente?",
      type: "text",
      image: "https://s3.amazonaws.com/arc-wordpress-client-uploads/infobae-wp/wp-content/uploads/2018/07/18192150/Florero-Guerra-Colombia-21.jpg",
      options: [
        { letter: "A", text: "Decorar una fiesta con el florero de Llorente." },
        { letter: "B", text: "Provocar un conflicto para impulsar la protesta.", correct: true },
        { letter: "C", text: "Entregar el florero como regalo al virrey." },
        { letter: "D", text: "Comprar el florero para una familia de Santa Fe." }
      ]
    },
    {
      number: 2,
      text: "¿Por qué los criollos querían que Antonio Villavicencio visitara Santa Fe?",
      type: "text",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqY-ohzgbbWTis99IbrkZ_ats7XPkHT0Q9qX75wId4SS4U_0YtyUidYaw&s=10",
      options: [
        { letter: "A", text: "Porque era un comerciante famoso en Santa Fe." },
        { letter: "B", text: "Porque era un militar que luchaba contra España." },
        { letter: "C", text: "Porque su visita impulsaría el movimiento criollo.", correct: true },
        { letter: "D", text: "Porque acababa de ser nombrado nuevo virrey." }
      ]
    },
    {
      number: 3,
      text: "De acuerdo con el video, ¿qué sucedió después de que comenzó la discusión por el florero?",
      type: "text",
      image: null,
      options: [
        { letter: "A", text: "El pueblo se quedó en casa sin participar." },
        { letter: "B", text: "Las autoridades españolas salieron del país." },
        { letter: "C", text: "La gente salió a protestar y pedir cambios.", correct: true },
        { letter: "D", text: "Los criollos fueron enviados a España." }
      ]
    },
    {
      number: 4,
      text: "¿Cuál era una de las principales diferencias entre los españoles y los criollos durante la época colonial?",
      type: "text",
      image: "https://archivobogota.secretariageneral.gov.co/sites/default/files/Captura%20de%20pantalla%202018-02-16%20a%20la%28s%29%2010.38.43.png",
      options: [
        { letter: "A", text: "Los criollos hablaban un idioma distinto." },
        { letter: "B", text: "Los españoles tenían los cargos más altos.", correct: true },
        { letter: "C", text: "Los criollos no podían ir a la escuela." },
        { letter: "D", text: "Los españoles no vivían en Nueva Granada." }
      ]
    },
    {
      number: 5,
      text: "Según el video, ¿por qué el 20 de julio de 1810 no significó la independencia definitiva de Colombia?",
      type: "text",
      image: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Reyerta_del_20_de_julio_de_1810.jpg/960px-Reyerta_del_20_de_julio_de_1810.jpg",
      options: [
        { letter: "A", text: "Porque ese día solo empezó un largo proceso.", correct: true },
        { letter: "B", text: "Porque España nunca gobernó Nueva Granada." },
        { letter: "C", text: "Porque el pueblo quería seguir con España." },
        { letter: "D", text: "Porque devolvieron el florero y todo acabó." }
      ]
    }
  ]
};
