// Minimal canvas confetti burst — kept dependency-free so the app works with
// no network at all once the page has loaded.

function fireConfetti(canvasEl) {
  const ctx = canvasEl.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const resize = () => {
    canvasEl.width = canvasEl.clientWidth * dpr;
    canvasEl.height = canvasEl.clientHeight * dpr;
  };
  resize();

  const colors = ['#D91E2B', '#FFC93C', '#1B2A4A', '#FFF6E2', '#47B26B'];
  const count = 160;
  const particles = Array.from({ length: count }, () => ({
    x: (canvasEl.width / 2) + (Math.random() - 0.5) * canvasEl.width * 0.3,
    y: canvasEl.height * 0.15,
    vx: (Math.random() - 0.5) * 8 * dpr,
    vy: (Math.random() * -6 - 4) * dpr,
    size: (Math.random() * 8 + 5) * dpr,
    color: colors[Math.floor(Math.random() * colors.length)],
    rotation: Math.random() * 360,
    rotSpeed: (Math.random() - 0.5) * 12,
    shape: Math.random() > 0.5 ? 'rect' : 'circle'
  }));

  const gravity = 0.22 * dpr;
  let frame = 0;
  const maxFrames = 240;

  function tick() {
    frame++;
    ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
    particles.forEach(p => {
      p.vy += gravity;
      p.x += p.vx;
      p.y += p.vy;
      p.rotation += p.rotSpeed;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rotation * Math.PI) / 180);
      ctx.fillStyle = p.color;
      if (p.shape === 'rect') {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
    if (frame < maxFrames) {
      requestAnimationFrame(tick);
    } else {
      ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
    }
  }
  requestAnimationFrame(tick);
}
