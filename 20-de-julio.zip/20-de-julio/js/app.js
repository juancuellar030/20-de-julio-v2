(() => {
  'use strict';

  // ---------- State ----------
  const state = {
    grade: null,        // '1-3' | '4-5'
    quiz: null,          // QUIZ_1_3 | QUIZ_4_5
    qIndex: 0,
    score: 0,
    answered: false,
    timerId: null,
    timerPaused: false,
    timeLeft: 0,
    timeTotal: 18000, // ms, generous for classroom reading aloud
  };

  // ---------- Scene helpers ----------
  const scenes = {
    title: document.getElementById('scene-title'),
    grade: document.getElementById('scene-grade'),
    videos: document.getElementById('scene-videos'),
    quiz: document.getElementById('scene-quiz'),
    end: document.getElementById('scene-end'),
  };

  function showScene(name) {
    Object.values(scenes).forEach(s => s.classList.remove('active'));
    scenes[name].classList.add('active');
  }

  // ---------- Background watermark crossfade ----------
  (function watermarkLoop() {
    const slides = Array.from(document.querySelectorAll('.bg-slide'));
    let i = 0;
    setInterval(() => {
      slides[i].classList.remove('active');
      i = (i + 1) % slides.length;
      slides[i].classList.add('active');
    }, 6000);
  })();

  // ---------- SCENE 0: Title ----------
  document.getElementById('btn-enter').addEventListener('click', () => {
    SFX.playClick();
    showScene('grade');
  });

  // ---------- SCENE 0b: Grade picker ----------
  document.querySelectorAll('.grade-card').forEach(card => {
    card.addEventListener('click', () => {
      SFX.playClick();
      state.grade = card.dataset.grade;
      state.quiz = state.grade === '1-3' ? QUIZ_1_3 : QUIZ_4_5;
      setupVideosScene();
      showScene('videos');
    });
  });

  // ---------- SCENE 1: Videos ----------
  const historyTitle = document.getElementById('history-video-title');
  const historyFrame = document.getElementById('history-frame');
  const historyPlaceholder = document.getElementById('history-placeholder');
  const anthemFrame = document.getElementById('anthem-frame');
  const anthemPlaceholder = document.getElementById('anthem-placeholder');
  const anthemAudioEl = document.getElementById('anthem-audio');

  function setupVideosScene() {
    historyTitle.textContent = state.grade === '1-3'
      ? 'La historia del 20 de julio (1°–3°)'
      : 'La historia del 20 de julio (4°–5°)';
    // reset frames back to placeholders in case teacher revisits
    historyFrame.innerHTML = '';
    historyFrame.appendChild(historyPlaceholder);
    historyPlaceholder.classList.remove('hidden');
    anthemFrame.innerHTML = '';
    anthemFrame.appendChild(anthemPlaceholder);
    anthemPlaceholder.classList.remove('hidden');
    anthemAudioEl.pause();
    anthemAudioEl.currentTime = 0;
  }

  function embedYouTube(container, videoId, autoplay = true) {
    container.innerHTML = '';
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?rel=0${autoplay ? '&autoplay=1' : ''}`;
    iframe.title = 'YouTube video player';
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');
    iframe.setAttribute('allowfullscreen', '');
    container.appendChild(iframe);
  }

  document.getElementById('btn-anthem-video').addEventListener('click', () => {
    anthemAudioEl.pause();
    embedYouTube(anthemFrame, 'oBtJ--lICJg', true);
  });

  document.getElementById('btn-anthem-audio').addEventListener('click', () => {
    anthemFrame.innerHTML = '';
    const label = document.createElement('div');
    label.className = 'video-placeholder';
    label.innerHTML = '<span class="video-icon">🔊</span>';
    anthemFrame.appendChild(label);
    anthemAudioEl.play().catch(() => {
      // Local MP3 missing or blocked — fall back to muted-visual YouTube audio mode
      embedYouTube(anthemFrame, 'oBtJ--lICJg', true);
    });
  });

  document.getElementById('btn-history-video').addEventListener('click', () => {
    embedYouTube(historyFrame, state.quiz.historyVideoId, true);
  });

  document.getElementById('btn-to-quiz').addEventListener('click', () => {
    SFX.playClick();
    startQuiz();
  });

  // ---------- SCENE 2: Quiz engine ----------
  const quizIntroEl = document.getElementById('quiz-intro');
  const quizQuestionEl = document.getElementById('quiz-question');
  const spiralEl = document.getElementById('spiral-transition');
  const preguntaNumberEl = document.getElementById('pregunta-number');
  const questionProgressEl = document.getElementById('question-progress');
  const questionTextEl = document.getElementById('question-text');
  const questionImageFrame = document.getElementById('question-image-frame');
  const questionImageEl = document.getElementById('question-image');
  const questionOptionsEl = document.getElementById('question-options');
  const timerBarEl = document.getElementById('timer-bar');
  const nextBtn = document.getElementById('btn-next-question');
  const btnPause = document.getElementById('btn-pause-timer');
  const btnSkip = document.getElementById('btn-skip-timer');

  function startQuiz() {
    state.qIndex = 0;
    state.score = 0;
    showScene('quiz');
    showIntroBeat();
  }

  function showIntroBeat() {
    quizQuestionEl.classList.remove('visible');
    nextBtn.classList.add('hidden');
    spiralEl.classList.remove('active');
    quizIntroEl.classList.add('visible');
    const q = state.quiz.questions[state.qIndex];
    preguntaNumberEl.textContent = `N° ${q.number}`;
    setTimeout(runSpiralTransition, 1800);
  }

  function runSpiralTransition() {
    quizIntroEl.classList.remove('visible');
    spiralEl.classList.add('active');
    setTimeout(() => {
      spiralEl.classList.remove('active');
      showQuestion();
    }, 950);
  }

  function showQuestion() {
    const q = state.quiz.questions[state.qIndex];
    state.answered = false;
    state.timerPaused = false;

    questionProgressEl.textContent = `Pregunta ${q.number} de ${state.quiz.questions.length}`;
    questionTextEl.textContent = q.text;

    if (q.image) {
      questionImageFrame.classList.remove('no-image');
      questionImageEl.src = q.image;
      questionImageEl.alt = `Imagen de apoyo — pregunta ${q.number}`;
      questionImageEl.style.display = '';
    } else {
      questionImageFrame.classList.add('no-image');
      questionImageEl.style.display = 'none';
    }

    // Build options
    questionOptionsEl.innerHTML = '';
    q.options.forEach((opt, idx) => {
      const pill = document.createElement('div');
      pill.className = 'option-pill';
      pill.dataset.correct = opt.correct ? 'true' : 'false';

      const btn = document.createElement('button');
      btn.className = 'option-hit';
      btn.setAttribute('aria-label', `Opción ${opt.letter}: ${opt.text}`);

      const circle = document.createElement('span');
      circle.className = 'letter-circle';
      circle.textContent = opt.letter;

      const textSpan = document.createElement('span');
      textSpan.className = 'option-text';
      if (opt.image) {
        const thumb = document.createElement('img');
        thumb.src = opt.image;
        thumb.alt = opt.text;
        thumb.className = 'option-thumb';
        textSpan.appendChild(thumb);
      }
      const label = document.createElement('span');
      label.textContent = opt.text;
      textSpan.appendChild(label);

      btn.appendChild(circle);
      btn.appendChild(textSpan);
      pill.appendChild(btn);
      questionOptionsEl.appendChild(pill);

      btn.addEventListener('click', () => selectOption(pill, opt));

      // staggered slide-in
      requestAnimationFrame(() => {
        setTimeout(() => pill.classList.add('entered'), idx * 110);
      });
    });

    quizQuestionEl.classList.add('visible');
    nextBtn.classList.add('hidden');
    startTimer();
  }

  function startTimer() {
    clearInterval(state.timerId);
    state.timeLeft = state.timeTotal;
    timerBarEl.style.width = '100%';
    btnPause.textContent = '⏸ Pausar';
    const tickMs = 100;
    state.timerId = setInterval(() => {
      if (state.timerPaused || state.answered) return;
      state.timeLeft -= tickMs;
      const pct = Math.max(0, (state.timeLeft / state.timeTotal) * 100);
      timerBarEl.style.width = pct + '%';
      if (state.timeLeft <= 0) {
        clearInterval(state.timerId);
        revealAnswer(null);
      }
    }, tickMs);
  }

  btnPause.addEventListener('click', () => {
    state.timerPaused = !state.timerPaused;
    btnPause.textContent = state.timerPaused ? '▶ Reanudar' : '⏸ Pausar';
  });

  btnSkip.addEventListener('click', () => {
    if (!state.answered) {
      clearInterval(state.timerId);
      revealAnswer(null);
    }
  });

  function selectOption(pill, opt) {
    if (state.answered) return;
    state.answered = true;
    clearInterval(state.timerId);
    revealAnswer(opt);
  }

  function revealAnswer(chosenOpt) {
    state.answered = true;
    const pills = Array.from(questionOptionsEl.children);
    let correctWasChosen = false;
    pills.forEach(pill => {
      const isCorrect = pill.dataset.correct === 'true';
      pill.classList.add('locked');
      if (isCorrect) {
        pill.classList.add('correct-reveal');
      } else {
        pill.classList.add('wrong-reveal');
      }
    });
    if (chosenOpt && chosenOpt.correct) correctWasChosen = true;

    if (correctWasChosen) {
      state.score++;
      SFX.playCorrect();
    } else {
      SFX.playIncorrect();
    }

    nextBtn.classList.remove('hidden');
  }

  nextBtn.addEventListener('click', () => {
    SFX.playClick();
    state.qIndex++;
    if (state.qIndex >= state.quiz.questions.length) {
      finishQuiz();
    } else {
      showIntroBeat();
    }
  });

  // ---------- SCENE 3: Congrats ----------
  function finishQuiz() {
    showScene('end');
    document.getElementById('score-display').textContent = `${state.score}/${state.quiz.questions.length}`;
    const canvas = document.getElementById('confetti-canvas');
    requestAnimationFrame(() => fireConfetti(canvas));
  }

  document.getElementById('btn-retry').addEventListener('click', () => {
    SFX.playClick();
    startQuiz();
  });
  document.getElementById('btn-back-videos').addEventListener('click', () => {
    SFX.playClick();
    setupVideosScene();
    showScene('videos');
  });
  document.getElementById('btn-home').addEventListener('click', () => {
    SFX.playClick();
    state.grade = null;
    state.quiz = null;
    showScene('title');
  });

  // Handle window resize for confetti canvas sizing
  window.addEventListener('resize', () => {
    const canvas = document.getElementById('confetti-canvas');
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
  });

})();
